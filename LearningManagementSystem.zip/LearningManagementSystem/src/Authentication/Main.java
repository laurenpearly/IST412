package Authentication;

public class Main {
    /**
     * Start the program.
     * @param args main method
     */
    public static void main(String[] args) {
        System.out.println("Hello world!");
    }
}