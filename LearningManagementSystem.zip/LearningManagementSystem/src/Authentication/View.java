package Authentication;

public class View {
    String userName;
    String userPassword;

    /**
     * Constructor for Authentication View.
     */
    public View() {

    }

    /**
     * Displays a user's input with login info.
     * @param userName User's input username.
     * @param userPassword User's input password.
     */
    public void display(String userName, String userPassword) {

    }
}
